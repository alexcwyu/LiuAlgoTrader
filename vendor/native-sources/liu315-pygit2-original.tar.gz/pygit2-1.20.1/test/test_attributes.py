# Copyright 2010-2026 The pygit2 contributors
#
# This file is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License, version 2,
# as published by the Free Software Foundation.
#
# In addition to the permissions in the GNU General Public License,
# the authors give you unlimited permission to link the compiled
# version of this file into combinations with other programs,
# and to distribute those combinations without any restriction
# coming from the use of this file.  (The General Public License
# restrictions do apply in other respects; for example, they cover
# modification of the file, and distribution when not linked into
# a combined executable.)
#
# This file is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; see the file COPYING.  If not, write to
# the Free Software Foundation, 51 Franklin Street, Fifth Floor,
# Boston, MA 02110-1301, USA.

# Standard Library
from pathlib import Path

from pygit2 import Repository


def test_no_attr(testrepo: Repository) -> None:
    assert testrepo.get_attr('file', 'foo') is None

    with (Path(testrepo.workdir) / '.gitattributes').open('w+') as f:
        print('*.py  text\n', file=f)
        print('*.jpg -text\n', file=f)
        print('*.sh  eol=lf\n', file=f)

    assert testrepo.get_attr('file.py', 'foo') is None
    assert testrepo.get_attr('file.py', 'text')
    assert not testrepo.get_attr('file.jpg', 'text')
    assert 'lf' == testrepo.get_attr('file.sh', 'eol')


def test_no_attr_aspath(testrepo: Repository) -> None:
    with (Path(testrepo.workdir) / '.gitattributes').open('w+') as f:
        print('*.py  text\n', file=f)

    assert testrepo.get_attr(Path('file.py'), 'text')
